require 'sinatra'
require 'sinatra/reloader'

require 'nokogiri'
require 'httparty'

get '/' do
  erb :index

end

get '/melon' do
  @rating = params[:rating]

  url = "http://www.melon.com/search/trend/index.htm"
  response = HTTParty.get(url)
  doc = Nokogiri::HTML(response)
  @first = doc.css("#conts > div.realtime_keywd > ol > li.rank01 > div.realtime_rank > div > a")
  @second = doc.css("#conts > div.realtime_keywd > ol > li.rank02 > div.realtime_rank > div > a")
  @third = doc.css("#conts > div.realtime_keywd > ol > li.rank03 > div.realtime_rank > div > a")

  erb :melon
end

get '/melonresult' do
  @result = params[:result]
  erb:melonresult
end
